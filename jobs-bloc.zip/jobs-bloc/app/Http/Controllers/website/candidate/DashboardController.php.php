<?php

namespace App\Http\Controllers\website\candidate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController.php extends Controller
{
    //
}
