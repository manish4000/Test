<?php echo e($slot); ?>

<?php /**PATH D:\project\jobs-bloc\jobs-bloc\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>