<?php

define('APP_PATH','http://127.0.0.1:8000/');
define("WEBSITE_TESTMONIAL_IMAGE",'uploads/website/testmonial/');
define("CANDIDATE_FEATURE_IMAGE_URL","uploads/candidate/feature-images/");
define("CANDIDATE_COVER_IMAGE_URL","uploads/candidate/cover-images/");
define("CANDIDATE_PORTFOLIO_IMAGE_URL","uploads/candidate/portfolio-images/");
define("CANDIDATE_CV_URL","uploads/candidate/cv/");


?>